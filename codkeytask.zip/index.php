<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Class 04 Template</title>
</head>
<body>
  
 
<body>

        <table border="1"  style="width: 100%;border-collapse: collapse">
           
            <!-- Table Caption -->
            <caption>Members Data</caption>
            <!-- Table body -->
            <tbody>
                <tr>
                    <td colspan="3" style="background-color: #4b4bcf;">
                       <span style="float: left;padding:10px; color: white">Your Insurance Plan</span>
                       <span style="float: right;background-color: yellow;padding:10px">RECOMMENDED</span>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" style="background-color: #00bcd4;">
                       <span style="display: block;text-align: center;padding: 5px;font-weight: 600;">SCHEDULE OF BENEFITS</span>
                    </td>
                </tr>
                <tr>
                    <td colspan="1">
                       <img src="./imagess.png" alt="">
                    </td>
                    <td colspan="2">
                    <table border="1"  style="width: 100%;border-collapse: collapse;">
  <tr>
    <th>Company</th>
    <th>Contact</th>
    <th>Country</th>
  </tr>
  <tr>
    <td>Alfreds Futterkiste</td>
    <td>Maria Anders</td>
    <td>Germany</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
</table>
                    </td>
                </tr>
               
              
            </tbody>
           
            <!-- Table Foot -->
            <!-- <tfoot>
                <tr>
                    <td colspan="2">Total Members</td>
                    <td colspan="1">Total Members</td>
                    <td colspan="2">Total Members</td>
                </tr>

            </tfoot> -->
        </table>
        
    </body>
</body>
</html>